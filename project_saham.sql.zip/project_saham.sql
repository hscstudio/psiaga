-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2015 at 02:56 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_siaga`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Administrator', '1', 1449393564);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/debug/*', 2, NULL, NULL, NULL, 1449411104, 1449411104),
('/debug/default/*', 2, NULL, NULL, NULL, 1449411105, 1449411105),
('/mimin/*', 2, NULL, NULL, NULL, 1449411090, 1449411090),
('/plant/*', 2, NULL, NULL, NULL, 1449411094, 1449411094),
('/profile/*', 2, NULL, NULL, NULL, 1449411095, 1449411095),
('/site/*', 2, NULL, NULL, NULL, 1449411096, 1449411096),
('Administrator', 1, NULL, NULL, NULL, 1449380439, 1449389986);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('Administrator', '/debug/*'),
('Administrator', '/debug/default/*'),
('Administrator', '/mimin/*'),
('Administrator', '/plant/*'),
('Administrator', '/profile/*'),
('Administrator', '/site/*');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `name`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'SD', NULL, 1449382525, 1, 1449382525, 1),
(2, 'SMP', NULL, 1449382536, 1, 1449382536, 1),
(3, 'SMA', NULL, 1449382544, 1, 1449382544, 1),
(4, 'S1', NULL, 1449382552, 1, 1449382552, 1),
(5, 'S2', NULL, 1449382558, 1, 1449382558, 1),
(6, 'S3', NULL, 1449382564, 1, 1449382564, 1);

-- --------------------------------------------------------

--
-- Table structure for table `farmer_education`
--

CREATE TABLE IF NOT EXISTS `farmer_education` (
  `id` int(11) NOT NULL,
  `education_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param` float(13,2) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `harvest_plant`
--

CREATE TABLE IF NOT EXISTS `harvest_plant` (
  `id` int(11) NOT NULL,
  `plant_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param1` float(13,2) DEFAULT NULL,
  `param2` float(13,2) DEFAULT NULL,
  `param3` float(13,2) DEFAULT NULL,
  `param4` float(13,2) DEFAULT NULL,
  `param5` float(13,2) DEFAULT NULL,
  `note1` varchar(255) DEFAULT NULL,
  `note2` varchar(255) DEFAULT NULL,
  `note3` varchar(255) DEFAULT NULL,
  `note4` varchar(255) DEFAULT NULL,
  `note5` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `harvest_tools`
--

CREATE TABLE IF NOT EXISTS `harvest_tools` (
  `id` int(11) NOT NULL,
  `tools_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param` float(13,2) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1449354663),
('m130524_201442_init', 1449354665),
('m140506_102106_rbac_init', 1449363312),
('m151024_072453_create_route_table', 1449363857);

-- --------------------------------------------------------

--
-- Table structure for table `plant`
--

CREATE TABLE IF NOT EXISTS `plant` (
  `id` int(11) NOT NULL,
  `type_plant_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `user_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`name`, `alias`, `type`, `status`) VALUES
('/*', '*', '', 0),
('/debug/*', '*', 'debug', 1),
('/debug/default/*', '*', 'debug/default', 1),
('/debug/default/db-explain', 'db-explain', 'debug/default', 1),
('/debug/default/download-mail', 'download-mail', 'debug/default', 1),
('/debug/default/index', 'index', 'debug/default', 1),
('/debug/default/toolbar', 'toolbar', 'debug/default', 1),
('/debug/default/view', 'view', 'debug/default', 1),
('/education/*', '*', 'education', 1),
('/education/create', 'create', 'education', 1),
('/education/delete', 'delete', 'education', 1),
('/education/index', 'index', 'education', 1),
('/education/update', 'update', 'education', 1),
('/education/view', 'view', 'education', 1),
('/farmer-education/*', '*', 'farmer-education', 1),
('/farmer-education/create', 'create', 'farmer-education', 1),
('/farmer-education/delete', 'delete', 'farmer-education', 1),
('/farmer-education/index', 'index', 'farmer-education', 1),
('/farmer-education/update', 'update', 'farmer-education', 1),
('/farmer-education/view', 'view', 'farmer-education', 1),
('/gii/*', '*', 'gii', 1),
('/gii/default/*', '*', 'gii/default', 1),
('/gii/default/action', 'action', 'gii/default', 1),
('/gii/default/diff', 'diff', 'gii/default', 1),
('/gii/default/index', 'index', 'gii/default', 1),
('/gii/default/preview', 'preview', 'gii/default', 1),
('/gii/default/view', 'view', 'gii/default', 1),
('/harvest-plant/*', '*', 'harvest-plant', 1),
('/harvest-plant/create', 'create', 'harvest-plant', 1),
('/harvest-plant/delete', 'delete', 'harvest-plant', 1),
('/harvest-plant/index', 'index', 'harvest-plant', 1),
('/harvest-plant/update', 'update', 'harvest-plant', 1),
('/harvest-plant/view', 'view', 'harvest-plant', 1),
('/harvest-tools/*', '*', 'harvest-tools', 1),
('/harvest-tools/create', 'create', 'harvest-tools', 1),
('/harvest-tools/delete', 'delete', 'harvest-tools', 1),
('/harvest-tools/index', 'index', 'harvest-tools', 1),
('/harvest-tools/update', 'update', 'harvest-tools', 1),
('/harvest-tools/view', 'view', 'harvest-tools', 1),
('/mimin/*', '*', 'mimin', 1),
('/mimin/role/*', '*', 'mimin/role', 1),
('/mimin/role/create', 'create', 'mimin/role', 1),
('/mimin/role/delete', 'delete', 'mimin/role', 1),
('/mimin/role/index', 'index', 'mimin/role', 1),
('/mimin/role/permission', 'permission', 'mimin/role', 1),
('/mimin/role/update', 'update', 'mimin/role', 1),
('/mimin/role/view', 'view', 'mimin/role', 1),
('/mimin/route/*', '*', 'mimin/route', 1),
('/mimin/route/create', 'create', 'mimin/route', 1),
('/mimin/route/delete', 'delete', 'mimin/route', 1),
('/mimin/route/generate', 'generate', 'mimin/route', 1),
('/mimin/route/index', 'index', 'mimin/route', 1),
('/mimin/route/update', 'update', 'mimin/route', 1),
('/mimin/route/view', 'view', 'mimin/route', 1),
('/mimin/user/*', '*', 'mimin/user', 1),
('/mimin/user/create', 'create', 'mimin/user', 1),
('/mimin/user/delete', 'delete', 'mimin/user', 1),
('/mimin/user/index', 'index', 'mimin/user', 1),
('/mimin/user/update', 'update', 'mimin/user', 1),
('/mimin/user/view', 'view', 'mimin/user', 1),
('/plant/*', '*', 'plant', 1),
('/plant/create', 'create', 'plant', 1),
('/plant/delete', 'delete', 'plant', 1),
('/plant/index', 'index', 'plant', 1),
('/plant/update', 'update', 'plant', 1),
('/plant/view', 'view', 'plant', 1),
('/profile/*', '*', 'profile', 1),
('/profile/create', 'create', 'profile', 1),
('/profile/delete', 'delete', 'profile', 1),
('/profile/index', 'index', 'profile', 1),
('/profile/update', 'update', 'profile', 1),
('/profile/view', 'view', 'profile', 1),
('/site/*', '*', 'site', 1),
('/site/about', 'about', 'site', 1),
('/site/captcha', 'captcha', 'site', 1),
('/site/contact', 'contact', 'site', 1),
('/site/error', 'error', 'site', 1),
('/site/index', 'index', 'site', 1),
('/site/login', 'login', 'site', 1),
('/site/logout', 'logout', 'site', 1),
('/site/request-password-reset', 'request-password-reset', 'site', 1),
('/site/reset-password', 'reset-password', 'site', 1),
('/site/signup', 'signup', 'site', 1),
('/state/*', '*', 'state', 1),
('/state/create', 'create', 'state', 1),
('/state/delete', 'delete', 'state', 1),
('/state/index', 'index', 'state', 1),
('/state/update', 'update', 'state', 1),
('/state/view', 'view', 'state', 1),
('/tools/*', '*', 'tools', 1),
('/tools/create', 'create', 'tools', 1),
('/tools/delete', 'delete', 'tools', 1),
('/tools/index', 'index', 'tools', 1),
('/tools/update', 'update', 'tools', 1),
('/tools/view', 'view', 'tools', 1),
('/type-plant/*', '*', 'type-plant', 1),
('/type-plant/create', 'create', 'type-plant', 1),
('/type-plant/delete', 'delete', 'type-plant', 1),
('/type-plant/index', 'index', 'type-plant', 1),
('/type-plant/update', 'update', 'type-plant', 1),
('/type-plant/view', 'view', 'type-plant', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Cilodong', NULL, 1449368826, 1, 1449379739, 1),
(2, 'Pancoran Mas', NULL, 1449382632, 1, 1449382632, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE IF NOT EXISTS `tools` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `type_plant`
--

CREATE TABLE IF NOT EXISTS `type_plant` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `params` varchar(500) DEFAULT NULL,
  `units` varchar(500) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_plant`
--

INSERT INTO `type_plant` (`id`, `name`, `params`, `units`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Padi Palawija', 'Luas Panen|Hasil|Produksi', 'Ha|Ku/Ha|Ton', NULL, 1449380103, 1, 1449383970, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'cYofUxpZ3CTHmO-YAx_7Cj0rWqQE1A0h', '$2y$13$dElMHaPVfR0ThWkDWgABpOyikpbcUQD1Uc9fy3A.wPZetbC.qHigO', NULL, 'admin@gmail.com', 1, 1449364155, 1449411001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmer_education`
--
ALTER TABLE `farmer_education`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `education_id` (`education_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `plant_id` (`plant_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `tools_id` (`tools_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `plant`
--
ALTER TABLE `plant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`,`state_id`), ADD KEY `user_id` (`user_id`,`state_id`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type_plant`
--
ALTER TABLE `type_plant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `farmer_education`
--
ALTER TABLE `farmer_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `plant`
--
ALTER TABLE `plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `type_plant`
--
ALTER TABLE `type_plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `farmer_education`
--
ALTER TABLE `farmer_education`
ADD CONSTRAINT `farmer_education_ibfk_1` FOREIGN KEY (`education_id`) REFERENCES `education` (`id`),
ADD CONSTRAINT `farmer_education_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
ADD CONSTRAINT `harvest_plant_ibfk_1` FOREIGN KEY (`plant_id`) REFERENCES `plant` (`id`),
ADD CONSTRAINT `harvest_plant_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
ADD CONSTRAINT `harvest_tools_ibfk_1` FOREIGN KEY (`tools_id`) REFERENCES `tools` (`id`),
ADD CONSTRAINT `harvest_tools_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
ADD CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `profile_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
