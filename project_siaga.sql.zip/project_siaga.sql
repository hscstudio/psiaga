-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2015 at 04:11 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_siaga`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Administrator', '1', 1449393564),
('Daerah', '10', 1449721678),
('Daerah', '11', 1449721644),
('Daerah', '12', 1449721625),
('Daerah', '13', 1449721614),
('Daerah', '2', 1449543604),
('Daerah', '3', 1449543579),
('Daerah', '5', 1449721601),
('Daerah', '6', 1449721668),
('Daerah', '7', 1449721653),
('Daerah', '8', 1449721661),
('Daerah', '9', 1449721634),
('Pusat', '4', 1449543567);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/debug/*', 2, NULL, NULL, NULL, 1449411104, 1449411104),
('/debug/default/*', 2, NULL, NULL, NULL, 1449411105, 1449411105),
('/education/*', 2, NULL, NULL, NULL, 1449543135, 1449543135),
('/farmer-education-report/*', 2, NULL, NULL, NULL, 1449644166, 1449644166),
('/farmer-education/*', 2, NULL, NULL, NULL, 1449543142, 1449543142),
('/gii/*', 2, NULL, NULL, NULL, 1449543453, 1449543453),
('/gii/default/*', 2, NULL, NULL, NULL, 1449543466, 1449543466),
('/gridview/*', 2, NULL, NULL, NULL, 1449543147, 1449543147),
('/gridview/export/*', 2, NULL, NULL, NULL, 1449543148, 1449543148),
('/harvest-plant-report/*', 2, NULL, NULL, NULL, 1449644167, 1449644167),
('/harvest-plant/*', 2, NULL, NULL, NULL, 1449544646, 1449544646),
('/harvest-tools-report/*', 2, NULL, NULL, NULL, 1449644171, 1449644171),
('/harvest-tools/*', 2, NULL, NULL, NULL, 1449543150, 1449543150),
('/mimin/*', 2, NULL, NULL, NULL, 1449411090, 1449411090),
('/mimin/role/*', 2, NULL, NULL, NULL, 1449543461, 1449543461),
('/mimin/route/*', 2, NULL, NULL, NULL, 1449543461, 1449543461),
('/mimin/user/*', 2, NULL, NULL, NULL, 1449543165, 1449543165),
('/note/*', 2, NULL, NULL, NULL, 1449543171, 1449543171),
('/plant/*', 2, NULL, NULL, NULL, 1449544785, 1449544785),
('/profile/*', 2, NULL, NULL, NULL, 1449411095, 1449411095),
('/site/*', 2, NULL, NULL, NULL, 1449411096, 1449411096),
('/state/*', 2, NULL, NULL, NULL, 1449543180, 1449543180),
('/tools/*', 2, NULL, NULL, NULL, 1449543182, 1449543182),
('/type-plant/*', 2, NULL, NULL, NULL, 1449543182, 1449543182),
('/type-tools/*', 2, NULL, NULL, NULL, 1449715727, 1449715727),
('Administrator', 1, NULL, NULL, NULL, 1449380439, 1449389986),
('Daerah', 1, NULL, NULL, NULL, 1449469397, 1449469397),
('Pusat', 1, NULL, NULL, NULL, 1449469386, 1449469386);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('Administrator', '/debug/*'),
('Administrator', '/debug/default/*'),
('Daerah', '/debug/default/*'),
('Pusat', '/debug/default/*'),
('Administrator', '/education/*'),
('Pusat', '/education/*'),
('Administrator', '/farmer-education-report/*'),
('Pusat', '/farmer-education-report/*'),
('Administrator', '/farmer-education/*'),
('Daerah', '/farmer-education/*'),
('Pusat', '/farmer-education/*'),
('Administrator', '/gii/*'),
('Administrator', '/gii/default/*'),
('Administrator', '/gridview/*'),
('Daerah', '/gridview/*'),
('Pusat', '/gridview/*'),
('Administrator', '/gridview/export/*'),
('Daerah', '/gridview/export/*'),
('Pusat', '/gridview/export/*'),
('Administrator', '/harvest-plant-report/*'),
('Pusat', '/harvest-plant-report/*'),
('Administrator', '/harvest-plant/*'),
('Daerah', '/harvest-plant/*'),
('Pusat', '/harvest-plant/*'),
('Administrator', '/harvest-tools-report/*'),
('Pusat', '/harvest-tools-report/*'),
('Administrator', '/harvest-tools/*'),
('Daerah', '/harvest-tools/*'),
('Pusat', '/harvest-tools/*'),
('Administrator', '/mimin/*'),
('Administrator', '/mimin/role/*'),
('Administrator', '/mimin/route/*'),
('Administrator', '/mimin/user/*'),
('Pusat', '/mimin/user/*'),
('Administrator', '/note/*'),
('Daerah', '/note/*'),
('Pusat', '/note/*'),
('Administrator', '/plant/*'),
('Pusat', '/plant/*'),
('Administrator', '/profile/*'),
('Daerah', '/profile/*'),
('Pusat', '/profile/*'),
('Administrator', '/site/*'),
('Daerah', '/site/*'),
('Pusat', '/site/*'),
('Administrator', '/state/*'),
('Pusat', '/state/*'),
('Administrator', '/tools/*'),
('Pusat', '/tools/*'),
('Administrator', '/type-plant/*'),
('Pusat', '/type-plant/*'),
('Administrator', '/type-tools/*'),
('Pusat', '/type-tools/*');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `name`, `unit`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'SD', 'orang', NULL, 1449382525, 1, 1449382525, 1),
(2, 'SMP', 'orang', NULL, 1449382536, 1, 1449382536, 1),
(3, 'SMA', 'orang', NULL, 1449382544, 1, 1449382544, 1),
(4, 'S1', 'orang', NULL, 1449382552, 1, 1449382552, 1),
(5, 'S2', 'orang', NULL, 1449382558, 1, 1449382558, 1),
(6, 'S3', 'orang', NULL, 1449382564, 1, 1449382564, 1);

-- --------------------------------------------------------

--
-- Table structure for table `farmer_education`
--

CREATE TABLE IF NOT EXISTS `farmer_education` (
  `id` int(11) NOT NULL,
  `education_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param` float(13,2) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `farmer_education`
--

INSERT INTO `farmer_education` (`id`, `education_id`, `state_id`, `year`, `quarter`, `param`, `note`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 4, 2015, 4, 10.00, 'tes', NULL, NULL, 1449585799, 3),
(2, 3, 4, 2015, 4, 20.00, '', NULL, NULL, 1449585808, 3),
(3, 4, 4, 2015, 4, 5.00, '', NULL, NULL, 1449585814, 3);

-- --------------------------------------------------------

--
-- Table structure for table `harvest_plant`
--

CREATE TABLE IF NOT EXISTS `harvest_plant` (
  `id` int(11) NOT NULL,
  `plant_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param1` float(13,2) DEFAULT NULL,
  `param2` float(13,2) DEFAULT NULL,
  `param3` float(13,2) DEFAULT NULL,
  `param4` float(13,2) DEFAULT NULL,
  `param5` float(13,2) DEFAULT NULL,
  `note1` varchar(255) DEFAULT NULL,
  `note2` varchar(255) DEFAULT NULL,
  `note3` varchar(255) DEFAULT NULL,
  `note4` varchar(255) DEFAULT NULL,
  `note5` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `harvest_plant`
--

INSERT INTO `harvest_plant` (`id`, `plant_id`, `state_id`, `year`, `quarter`, `param1`, `param2`, `param3`, `param4`, `param5`, `note1`, `note2`, `note3`, `note4`, `note5`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 1, 2015, 4, 41363.00, 47.75, 197511.00, NULL, NULL, 'ok', 'mantap', 'sukses', NULL, NULL, 1449549113, 2, 1449549326, 2),
(2, 2, 1, 2015, 4, 1.00, 2.00, 3.00, NULL, NULL, '', '', '', NULL, NULL, 1449550040, 2, 1449550040, 2),
(3, 3, 1, 2015, 4, 1.00, 2.00, 3.00, NULL, NULL, '', '', '', NULL, NULL, 1449550067, 2, 1449550067, 2),
(4, 1, 4, 2015, 4, 1.00, 2.00, 3.00, NULL, NULL, 'bagus', 'top', 'bikin usaha', NULL, NULL, 1449582624, 3, 1449582624, 3);

-- --------------------------------------------------------

--
-- Table structure for table `harvest_tools`
--

CREATE TABLE IF NOT EXISTS `harvest_tools` (
  `id` int(11) NOT NULL,
  `tools_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `quarter` int(1) NOT NULL,
  `param1` float(13,2) DEFAULT NULL,
  `param2` float(13,2) DEFAULT NULL,
  `param3` float(13,2) DEFAULT NULL,
  `param4` float(13,2) DEFAULT NULL,
  `param5` float(13,2) DEFAULT NULL,
  `note1` varchar(255) DEFAULT NULL,
  `note2` varchar(255) DEFAULT NULL,
  `note3` varchar(255) DEFAULT NULL,
  `note4` varchar(255) DEFAULT NULL,
  `note5` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `harvest_tools`
--

INSERT INTO `harvest_tools` (`id`, `tools_id`, `state_id`, `year`, `quarter`, `param1`, `param2`, `param3`, `param4`, `param5`, `note1`, `note2`, `note3`, `note4`, `note5`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 1, 2015, 4, 100.00, NULL, NULL, NULL, NULL, 'ok', NULL, NULL, NULL, NULL, 1449717022, 1, 1449717022, 1),
(2, 2, 2, 2015, 4, 20.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1449717097, 1, 1449717097, 1);

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1449354663),
('m130524_201442_init', 1449354665),
('m140506_102106_rbac_init', 1449363312),
('m151024_072453_create_route_table', 1449363857);

-- --------------------------------------------------------

--
-- Table structure for table `plant`
--

CREATE TABLE IF NOT EXISTS `plant` (
  `id` int(11) NOT NULL,
  `type_plant_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plant`
--

INSERT INTO `plant` (`id`, `type_plant_id`, `name`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 'Padi', NULL, 1449544997, 4, 1449544997, 4),
(2, 1, 'Jagung', NULL, 1449545007, 4, 1449545007, 4),
(3, 1, 'Kedelai', NULL, 1449545018, 4, 1449545018, 4),
(4, 1, 'Kacang Tanah', NULL, 1449545035, 4, 1449545035, 4),
(5, 1, 'Kacang Hijau', NULL, 1449545049, 4, 1449545049, 4),
(6, 1, 'Ubi Kayu', NULL, 1449545062, 4, 1449545062, 4),
(7, 1, 'Ubi Jalar', NULL, 1449545076, 4, 1449545076, 4),
(8, 2, 'Bawang Merah', NULL, 1449545208, 4, 1449545208, 4),
(9, 2, 'Kembang Kol', NULL, 1449545222, 4, 1449545222, 4),
(10, 2, 'Petsai/Sawi', NULL, 1449545239, 4, 1449545239, 4),
(11, 2, 'Kacang Panjang', NULL, 1449545258, 4, 1449545258, 4),
(12, 2, 'Cabe Besar', NULL, 1449545273, 4, 1449545273, 4),
(13, 2, 'Cabe Rawit', NULL, 1449545284, 4, 1449545284, 4),
(14, 2, 'Tomat', NULL, 1449545298, 4, 1449545298, 4),
(15, 2, 'Terong', NULL, 1449545309, 4, 1449545309, 4),
(16, 2, 'Buncis', NULL, 1449545322, 4, 1449545322, 4),
(17, 2, 'Ketimun', NULL, 1449545338, 4, 1449545338, 4),
(18, 2, 'Kangkung', NULL, 1449545405, 4, 1449545405, 4),
(19, 2, 'Bayam', NULL, 1449545407, 4, 1449545407, 4),
(20, 2, 'Melon', NULL, 1449545409, 4, 1449545409, 4),
(21, 2, 'Semangka', NULL, 1449545422, 4, 1449545422, 4),
(22, 3, 'Alpukat', NULL, 1449545489, 4, 1449545489, 4),
(23, 3, 'Belimbing', NULL, 1449545491, 4, 1449545491, 4),
(24, 3, 'Duku', NULL, 1449545493, 4, 1449545493, 4),
(25, 3, 'Durian', NULL, 1449545495, 4, 1449545495, 4),
(26, 3, 'Jambu Biji', NULL, 1449545497, 4, 1449545497, 4),
(27, 3, 'Jambu Air', NULL, 1449545522, 4, 1449545522, 4),
(28, 3, 'Jeruk Siam', NULL, 1449545533, 4, 1449545533, 4),
(29, 3, 'Jeruk Besar', NULL, 1449545541, 4, 1449545541, 4),
(30, 3, 'Mangga', NULL, 1449545548, 4, 1449545548, 4),
(31, 3, 'Manggis', NULL, 1449545553, 4, 1449545553, 4),
(32, 3, 'Nangka', NULL, 1449545580, 4, 1449545580, 4),
(33, 3, 'Nenas', NULL, 1449545598, 4, 1449545598, 4),
(34, 3, 'Pepaya', NULL, 1449545600, 4, 1449545600, 4),
(35, 3, 'Pisang', NULL, 1449545615, 4, 1449545615, 4),
(36, 3, 'Rambutan', NULL, 1449545619, 4, 1449545619, 4),
(37, 3, 'Salak', NULL, 1449545624, 4, 1449545624, 4),
(38, 3, 'Sawo', NULL, 1449545633, 4, 1449545633, 4),
(39, 3, 'Sirsak', NULL, 1449545639, 4, 1449545639, 4),
(40, 3, 'Sukun', NULL, 1449545677, 4, 1449545677, 4),
(41, 3, 'Melinjo', NULL, 1449545682, 4, 1449545682, 4),
(42, 3, 'Petai', NULL, 1449545691, 4, 1449545691, 4),
(43, 3, 'Jengkol', NULL, 1449545697, 4, 1449545697, 4);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `user_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`name`, `alias`, `type`, `status`) VALUES
('/*', '*', '', 0),
('/debug/*', '*', 'debug', 1),
('/debug/default/*', '*', 'debug/default', 1),
('/debug/default/db-explain', 'db-explain', 'debug/default', 1),
('/debug/default/download-mail', 'download-mail', 'debug/default', 1),
('/debug/default/index', 'index', 'debug/default', 1),
('/debug/default/toolbar', 'toolbar', 'debug/default', 1),
('/debug/default/view', 'view', 'debug/default', 1),
('/education/*', '*', 'education', 1),
('/education/create', 'create', 'education', 1),
('/education/delete', 'delete', 'education', 1),
('/education/index', 'index', 'education', 1),
('/education/update', 'update', 'education', 1),
('/education/view', 'view', 'education', 1),
('/farmer-education-report/*', '*', 'farmer-education-report', 1),
('/farmer-education-report/index', 'index', 'farmer-education-report', 1),
('/farmer-education/*', '*', 'farmer-education', 1),
('/farmer-education/create', 'create', 'farmer-education', 1),
('/farmer-education/delete', 'delete', 'farmer-education', 1),
('/farmer-education/index', 'index', 'farmer-education', 1),
('/farmer-education/update', 'update', 'farmer-education', 1),
('/farmer-education/view', 'view', 'farmer-education', 1),
('/gii/*', '*', 'gii', 1),
('/gii/default/*', '*', 'gii/default', 1),
('/gii/default/action', 'action', 'gii/default', 1),
('/gii/default/diff', 'diff', 'gii/default', 1),
('/gii/default/index', 'index', 'gii/default', 1),
('/gii/default/preview', 'preview', 'gii/default', 1),
('/gii/default/view', 'view', 'gii/default', 1),
('/gridview/*', '*', 'gridview', 1),
('/gridview/export/*', '*', 'gridview/export', 1),
('/gridview/export/download', 'download', 'gridview/export', 1),
('/harvest-plant-report/*', '*', 'harvest-plant-report', 1),
('/harvest-plant-report/index', 'index', 'harvest-plant-report', 1),
('/harvest-plant/*', '*', 'harvest-plant', 1),
('/harvest-plant/create', 'create', 'harvest-plant', 1),
('/harvest-plant/delete', 'delete', 'harvest-plant', 1),
('/harvest-plant/index', 'index', 'harvest-plant', 1),
('/harvest-plant/update', 'update', 'harvest-plant', 1),
('/harvest-plant/view', 'view', 'harvest-plant', 1),
('/harvest-tools-report/*', '*', 'harvest-tools-report', 1),
('/harvest-tools-report/index', 'index', 'harvest-tools-report', 1),
('/harvest-tools/*', '*', 'harvest-tools', 1),
('/harvest-tools/create', 'create', 'harvest-tools', 1),
('/harvest-tools/delete', 'delete', 'harvest-tools', 1),
('/harvest-tools/index', 'index', 'harvest-tools', 1),
('/harvest-tools/update', 'update', 'harvest-tools', 1),
('/harvest-tools/view', 'view', 'harvest-tools', 1),
('/mimin/*', '*', 'mimin', 1),
('/mimin/role/*', '*', 'mimin/role', 1),
('/mimin/role/create', 'create', 'mimin/role', 1),
('/mimin/role/delete', 'delete', 'mimin/role', 1),
('/mimin/role/index', 'index', 'mimin/role', 1),
('/mimin/role/permission', 'permission', 'mimin/role', 1),
('/mimin/role/update', 'update', 'mimin/role', 1),
('/mimin/role/view', 'view', 'mimin/role', 1),
('/mimin/route/*', '*', 'mimin/route', 1),
('/mimin/route/create', 'create', 'mimin/route', 1),
('/mimin/route/delete', 'delete', 'mimin/route', 1),
('/mimin/route/generate', 'generate', 'mimin/route', 1),
('/mimin/route/index', 'index', 'mimin/route', 1),
('/mimin/route/update', 'update', 'mimin/route', 1),
('/mimin/route/view', 'view', 'mimin/route', 1),
('/mimin/user/*', '*', 'mimin/user', 1),
('/mimin/user/create', 'create', 'mimin/user', 1),
('/mimin/user/delete', 'delete', 'mimin/user', 1),
('/mimin/user/index', 'index', 'mimin/user', 1),
('/mimin/user/update', 'update', 'mimin/user', 1),
('/mimin/user/view', 'view', 'mimin/user', 1),
('/note/*', '*', 'note', 1),
('/note/create', 'create', 'note', 1),
('/note/delete', 'delete', 'note', 1),
('/note/download', 'download', 'note', 1),
('/note/index', 'index', 'note', 1),
('/note/update', 'update', 'note', 1),
('/note/view', 'view', 'note', 1),
('/plant/*', '*', 'plant', 1),
('/plant/create', 'create', 'plant', 1),
('/plant/delete', 'delete', 'plant', 1),
('/plant/index', 'index', 'plant', 1),
('/plant/update', 'update', 'plant', 1),
('/plant/view', 'view', 'plant', 1),
('/profile/*', '*', 'profile', 1),
('/profile/create', 'create', 'profile', 1),
('/profile/delete', 'delete', 'profile', 1),
('/profile/index', 'index', 'profile', 1),
('/profile/update', 'update', 'profile', 1),
('/profile/view', 'view', 'profile', 1),
('/site/*', '*', 'site', 1),
('/site/about', 'about', 'site', 1),
('/site/captcha', 'captcha', 'site', 1),
('/site/contact', 'contact', 'site', 1),
('/site/error', 'error', 'site', 1),
('/site/index', 'index', 'site', 1),
('/site/login', 'login', 'site', 1),
('/site/logout', 'logout', 'site', 1),
('/site/profile', 'profile', 'site', 1),
('/site/request-password-reset', 'request-password-reset', 'site', 1),
('/site/reset-password', 'reset-password', 'site', 1),
('/site/signup', 'signup', 'site', 1),
('/state/*', '*', 'state', 1),
('/state/create', 'create', 'state', 1),
('/state/delete', 'delete', 'state', 1),
('/state/index', 'index', 'state', 1),
('/state/map', 'map', 'state', 1),
('/state/map-detail', 'map-detail', 'state', 1),
('/state/update', 'update', 'state', 1),
('/state/view', 'view', 'state', 1),
('/tools/*', '*', 'tools', 1),
('/tools/create', 'create', 'tools', 1),
('/tools/delete', 'delete', 'tools', 1),
('/tools/index', 'index', 'tools', 1),
('/tools/update', 'update', 'tools', 1),
('/tools/view', 'view', 'tools', 1),
('/type-plant/*', '*', 'type-plant', 1),
('/type-plant/create', 'create', 'type-plant', 1),
('/type-plant/delete', 'delete', 'type-plant', 1),
('/type-plant/index', 'index', 'type-plant', 1),
('/type-plant/update', 'update', 'type-plant', 1),
('/type-plant/view', 'view', 'type-plant', 1),
('/type-tools/*', '*', 'type-tools', 1),
('/type-tools/create', 'create', 'type-tools', 1),
('/type-tools/delete', 'delete', 'type-tools', 1),
('/type-tools/index', 'index', 'type-tools', 1),
('/type-tools/update', 'update', 'type-tools', 1),
('/type-tools/view', 'view', 'type-tools', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `coords` varchar(500) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`, `coords`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Daha Utara', '14, 27, 21, 24, 34, 27, 54, 15, 70, 10, 106, 22, 138, 38, 158, 44, 176, 47, 172, 86, 146, 86, 141, 93, 134, 92, 129, 97, 118, 101, 113, 95, 89, 83, 84, 73, 38, 45, 21, 37', NULL, 1449368826, 1, 1449379739, 1),
(2, 'Daha Barat', '102, 153, 106, 146, 116, 147, 125, 137, 110, 127, 118, 118, 108, 111, 76, 107, 69, 102, 50, 101, 62, 129, 64, 155, 81, 165, 91, 171, 103, 176, 103, 167, 102, 161', NULL, 1449382632, 1, 1449382632, 1),
(3, 'Daha Selatan', '12, 27, 6, 32, 49, 101, 68, 101, 76, 107, 107, 111, 118, 117, 112, 127, 124, 135, 116, 147, 105, 147, 103, 176, 115, 180, 152, 155, 170, 137, 178, 96, 172, 91, 172, 85, 146, 85, 140, 95, 118, 101, 88, 81, 84, 72, 36, 45, 20, 37', NULL, 1449462933, 1, 1449462933, 1),
(4, 'Kalumpang', '150, 155, 161, 168, 167, 180, 174, 199, 160, 208, 131, 199, 125, 207, 116, 208, 114, 181', NULL, 1449462945, 1, 1449462945, 1),
(5, 'Simpur', '169, 135, 187, 160, 199, 176, 210, 185, 188, 203, 173, 197, 166, 180, 160, 167, 150, 155', NULL, 1449462954, 1, 1449462954, 1),
(6, 'Kandangan', '178, 95, 194, 101, 198, 118, 206, 119, 209, 141, 216, 155, 230, 164, 230, 177, 234, 186, 231, 192, 224, 193, 200, 177, 188, 161, 170, 136', NULL, NULL, 1, NULL, 1),
(7, 'Angkinang', '205, 119, 227, 125, 244, 136, 249, 169, 229, 162, 216, 156, 208, 139', NULL, NULL, 1, NULL, 1),
(8, 'Telaga Langsat', '245, 136, 252, 141, 263, 140, 309, 177, 278, 174, 257, 175, 250, 167', NULL, NULL, 1, NULL, 1),
(9, 'Sungai Raya', '160, 207, 174, 201, 188, 203, 210, 185, 226, 195, 225, 205, 222, 215, 220, 245, 207, 222', NULL, NULL, 1, NULL, 1),
(10, 'Padang Batung', '222, 247, 240, 256, 246, 252, 253, 255, 270, 249, 270, 231, 276, 205, 285, 198, 280, 175, 258, 176, 250, 169, 230, 164, 229, 177, 233, 186, 232, 193, 223, 193, 226, 205, 222, 215', NULL, NULL, 1, NULL, 1),
(11, 'Loksado', '282, 177, 308, 176, 350, 146, 376, 146, 398, 135, 408, 142, 390, 185, 364, 224, 332, 225, 322, 231, 317, 229, 307, 233, 299, 230, 285, 233, 271, 248, 270, 231, 275, 209, 284, 199', NULL, NULL, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE IF NOT EXISTS `tools` (
  `id` int(11) NOT NULL,
  `type_tools_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`id`, `type_tools_id`, `name`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 'Arit Bergerigi', NULL, 1449716275, 1, 1449716275, 1),
(2, 1, 'Power Threser', NULL, 1449716380, 1, 1449716380, 1),
(3, 1, 'Paddy Mower', NULL, 1449716391, 1, 1449716391, 1),
(4, 1, 'Terpal', NULL, 1449716404, 1, 1449716404, 1),
(5, 1, 'Cup Seller', NULL, 1449716416, 1, 1449716416, 1),
(6, 1, 'Mangal', NULL, 1449716428, 1, 1449716428, 1),
(7, 1, 'Pemimpil Kacang Tanah', NULL, 1449716440, 1, 1449716440, 1),
(8, 1, 'Alat Pengolahan Ccabe, Tomat, Nangka', NULL, 1449716451, 1, 1449716451, 1),
(9, 1, 'Alat Pemipil Jagung', NULL, 1449716461, 1, 1449716461, 1),
(10, 1, 'Box Dryer', NULL, 1449716472, 1, 1449716472, 1),
(11, 1, 'Penggilingan Padi', NULL, 1449716481, 1, 1449716481, 1),
(12, 2, 'Penggilingan Padi Izin HO nya Hidup', NULL, 1449716493, 1, 1449716493, 1),
(13, 2, 'Penggilingan Padi Izin HO nya Mati', NULL, 1449716503, 1, 1449716503, 1);

-- --------------------------------------------------------

--
-- Table structure for table `type_plant`
--

CREATE TABLE IF NOT EXISTS `type_plant` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `params` varchar(500) DEFAULT NULL,
  `units` varchar(500) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_plant`
--

INSERT INTO `type_plant` (`id`, `name`, `params`, `units`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Padi Palawija', 'Luas Panen|Hasil|Produksi', 'ha|kw/ha|ton', NULL, 1449380103, 1, 1449543952, 4),
(2, 'Sayur Semusim', 'Luas Tanam|Luas Panen|Produksi|Produktivitas', 'ha|ha|kw|kw/ha', NULL, 1449543841, 4, 1449544035, 4),
(3, 'Buah Tahunan', 'Tanaman Hasil|Produksi|Provit', 'pohon|kw|kw/pohon', NULL, 1449543913, 4, 1449543913, 4);

-- --------------------------------------------------------

--
-- Table structure for table `type_tools`
--

CREATE TABLE IF NOT EXISTS `type_tools` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `params` varchar(500) DEFAULT NULL,
  `units` varchar(500) DEFAULT NULL,
  `sort` int(5) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_tools`
--

INSERT INTO `type_tools` (`id`, `name`, `params`, `units`, `sort`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Alat Panen & Mesin Pasca Panen', 'jumlah', 'buah', NULL, NULL, 1, 1449716048, 1),
(2, 'Ho Penggilingan Padi', 'jumlah', 'buah', NULL, 1449716108, 1, 1449716108, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `state_id` int(11) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `state_id`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'cYofUxpZ3CTHmO-YAx_7Cj0rWqQE1A0h', '$2y$13$dElMHaPVfR0ThWkDWgABpOyikpbcUQD1Uc9fy3A.wPZetbC.qHigO', NULL, 'admin@gmail.com', 1, NULL, 1449364155, 1449542581),
(2, 'dahautara', '', '$2y$13$EO7vQbEaqKz5ftc9xXye7edC71f3U0D7/KmLpGhmMMrtB42EX1N8a', NULL, 'dahautara@gmail.com', 1, 1, 1449542618, 1449721363),
(3, 'dahabarat', '', '$2y$13$RZ25GYSTFqajV744.WLJceQtcWYyUia2Wh4uvpTciG.7KkyvHYUci', NULL, 'dahabarat@gmail.com', 1, 2, 1449542977, 1449721392),
(4, 'pusat', '', '$2y$13$MSTIeOnpe3GD0w2aKWn0AOwO3a2fNykrPW029L2zEbLp4mtejlkci', NULL, 'pusat@gmail.com', 1, NULL, 1449543102, 1449543102),
(5, 'dahaselatan', '', '$2y$13$tidEWJLCk2rshWtUhJD94uOlWy1KG3SC.BGWE3S.1eL0aERsTzIbq', NULL, 'dahaselatan@gmail.com', 1, 3, 1449721415, 1449721415),
(6, 'kalumpang', '', '$2y$13$5EB9tCVJfk86/tZtP8Xf9eTs8s7SvbWLo3mdHUURkrRvpRO5ESAw2', NULL, 'kalumpang@gmail.com', 1, 4, 1449721434, 1449721440),
(7, 'simpur', '', '$2y$13$pGIEv78LIzjPsJeUW/VmrO6b7qF72JyJXc.UNrIFXt3jf3MvD6WRG', NULL, 'simpur@gmail.com', 1, 5, 1449721458, 1449721458),
(8, 'kandangan', '', '$2y$13$KbqCzDRqqHCWLqHbgKX0G.Gvp.t9hlRunOQbwkeHSwLxoCxYAP8ye', NULL, 'kandangan@gmail.com', 1, 6, 1449721476, 1449721476),
(9, 'angkinang', '', '$2y$13$fxuZLqF/PRWp49Olg6uW0.nSWTU.ig8yMVrGK89dwfQEJ6hYA/qv2', NULL, 'angkinang@gmail.com', 1, 7, 1449721501, 1449721501),
(10, 'telagalangsat', '', '$2y$13$VZf3wreezgzjddq504lkQOwHIKtiUXQ4vYykNEfxtRcWTtrQPsuQ.', NULL, 'telagalangsat@gmail.com', 1, 8, 1449721522, 1449721522),
(11, 'sungairaya', '', '$2y$13$HMbGBgm2uiTC1bNWFUATm.WVlw9R5n3vg04yFI5G4AjkhvD8DKkcS', NULL, 'sungairaya@gmail.com', 1, 9, 1449721543, 1449721543),
(12, 'padangbatung', '', '$2y$13$pmJDaV4cQVnOXWO4KG/nB.iT2qI4V1z5Y1nqd6TI.M8kp1xkh78sW', NULL, 'padangbatung@gmail.com', 1, 10, 1449721566, 1449721566),
(13, 'loksado', '', '$2y$13$CEu9TkhsW9ApokuEfY8b2uHB.tUbmulkYm1YrN4QIqwAlqHdym.nK', NULL, 'loksado@gmail.com', 1, 11, 1449721589, 1449721589);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmer_education`
--
ALTER TABLE `farmer_education`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `education_id` (`education_id`,`state_id`,`year`,`quarter`), ADD UNIQUE KEY `education_id_2` (`education_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `plant_id` (`plant_id`,`state_id`,`year`,`quarter`), ADD UNIQUE KEY `plant_id_2` (`plant_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `tools_id` (`tools_id`,`state_id`,`year`,`quarter`), ADD UNIQUE KEY `tools_id_2` (`tools_id`,`state_id`,`year`,`quarter`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `plant`
--
ALTER TABLE `plant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`,`state_id`), ADD KEY `user_id` (`user_id`,`state_id`), ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`), ADD KEY `type_tools` (`type_tools_id`);

--
-- Indexes for table `type_plant`
--
ALTER TABLE `type_plant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type_tools`
--
ALTER TABLE `type_tools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `farmer_education`
--
ALTER TABLE `farmer_education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `plant`
--
ALTER TABLE `plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `type_plant`
--
ALTER TABLE `type_plant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `type_tools`
--
ALTER TABLE `type_tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `farmer_education`
--
ALTER TABLE `farmer_education`
ADD CONSTRAINT `farmer_education_ibfk_1` FOREIGN KEY (`education_id`) REFERENCES `education` (`id`),
ADD CONSTRAINT `farmer_education_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `harvest_plant`
--
ALTER TABLE `harvest_plant`
ADD CONSTRAINT `harvest_plant_ibfk_1` FOREIGN KEY (`plant_id`) REFERENCES `plant` (`id`),
ADD CONSTRAINT `harvest_plant_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `harvest_tools`
--
ALTER TABLE `harvest_tools`
ADD CONSTRAINT `harvest_tools_ibfk_1` FOREIGN KEY (`tools_id`) REFERENCES `tools` (`id`),
ADD CONSTRAINT `harvest_tools_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`);

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
ADD CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `profile_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `state` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
